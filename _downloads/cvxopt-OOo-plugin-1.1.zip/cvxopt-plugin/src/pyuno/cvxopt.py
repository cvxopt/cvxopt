import uno
import unohelper

from com.sun.star.lang import IllegalArgumentException, Locale

# pythonloader looks for a static g_ImplementationHelper variable
g_ImplementationHelper = unohelper.ImplementationHelper()

# used for storing supported interfaces of classes 
g_TypeTable = {}

try:
    from cvxopt import matrix, sqrt, log, exp
    from cvxopt import solvers, info
    CVXOPT_INSTALLED = True
except:
    CVXOPT_INSTALLED = False

def check_cvxopt_inst():

    if not CVXOPT_INSTALLED:
        return "Error: CVXOPT might not be installed"

    from cvxopt import info
    import re
    m = re.match('(\d)\.(\d)\.*(\d)*',info.version)
    ver = int(m.groups()[0])+0.1*int(m.groups()[1])

    if m.groups()[-1] is not None:
        ver = ver + 0.01*int(m.groups()[-1])

    if ver < 1.1: 
        return "Error: please upgrade CVXOPT to version 1.1 or later"

    if ver > 1.1: 
        return "Error: please upgrade CVXOPT plugin"

    return None
    
class cvxopt:
    def __init__(self, ctx):
        self.ServiceName = "org.openoffice.sheet.addin.cvxopt"
        self.AddInService = "com.sun.star.sheet.AddIn"
        self.ImplementationName = "org.openoffice.sheet.addin.cvxopt"
        self.SupportedServiceNames = (self.ServiceName, self.AddInService,)
        self.Locale = -1
		
    # XTypeProvider method implementations	
    def getTypes (self):
        global g_TypeTable
		
        if g_TypeTable.has_key (self.__class__):
            ret = g_TypeTable[self.__class__]
        else:
            ret = (
                uno.getTypeByName( "org.openoffice.sheet.addin.XCvxopt" ),
                uno.getTypeByName( "com.sun.star.sheet.XAddIn" ),
                uno.getTypeByName( "com.sun.star.lang.XLocalizable" ),
                uno.getTypeByName( "com.sun.star.lang.XServiceName" ),
                uno.getTypeByName( "com.sun.star.lang.XServiceInfo" ),
                uno.getTypeByName( "com.sun.star.lang.XTypeProvider" ),
                )
            g_TypeTable[self.__class__] = ret			
        return ret
			
    def getImplementationId (self):
        return uno.generateUuid ()
	
    # XServiceName method implementations
    def getServiceName(self):
        return self.ServiceName
	
    # XServiceInfo method implementations	
    def getImplementationName (self):
        return self.ImplementationName
	
    def supportsService(self, ServiceName):
        return (ServiceName in self.SupportedServiceNames)
	
    def getSupportedServiceNames (self):
        return self.SupportedServiceNames

    #
    # Xcvxopt method implementations
    #
    def clp(self, c, x, C, z):

        err = check_cvxopt_inst()
        if err: return err
        
        c = tuples_to_matrix(c)
        if min(c.size) != 1: return "c must be a vector"

        n = max(x.getRows().getCount(), x.getColumns().getCount())
        tmpx = min(x.getRows().getCount(), x.getColumns().getCount())
        if n != max(c.size) or tmpx != 1:
            return "incompatible dimensions of c and x"

        try:
            G, h, dims, A, b, IG, IA = parse_conic_constraints(C)
        except Exception, arg: 
            return "error in constraints: "+str(arg)

        if (G.size[1] != n): 
            return "incompatible dimensions of G and x"
       
        nc = max(z.getRows().getCount(), z.getColumns().getCount())
        if nc != len(C):
            return "incompatible dimensions of dual variables and G"

        try: sol = solvers.conelp(c[:], G, h, dims, A, b) 
        except Exception, arg: return str(arg)
 
        if sol['status'] == 'optimal':

            try: vector_to_CellRange(sol['x'], x)
            except Exception, arg: return "error in x: "+str(arg)
            
            try: vector_to_CellRange(sol['z'], z, IG)
            except Exception, arg: return "error in z: "+str(arg)
                
            try: vector_to_CellRange(sol['y'], z, IA)
            except Exception, arg: return "error in y: "+str(arg)
            
            return (c[:].T*sol['x'][:])[0]
        elif sol['status'] == 'primal infeasible':
            clearCellRange(x)

            try: vector_to_CellRange(sol['z'], z, IG)
            except Exception, arg: return "error in z: "+str(arg)
                
            try: vector_to_CellRange(sol['y'], z, IA)
            except Exception, arg: return "error in y: "+str(arg)

            return sol['status']
        elif sol['status'] == 'dual infeasible':
            clearCellRange(z)

            try: vector_to_CellRange(sol['x'], x)
            except Exception, arg: return "error in x: "+str(arg)

            return sol['status']
        else:
            for w in [x, z]: clearCellRange(w)
            return sol['status']

    def cqp(self, P, q, x, C, z):

        err = check_cvxopt_inst()
        if err: return err

        P = tuples_to_matrix(P)
        if (P.size[0] != P.size[1]): 
            return "P must be a symmetric positive semidefinite matrix"

        q = tuples_to_matrix(q)
        if max(q.size) != P.size[0] or min(q.size) != 1: 
            return "incompatible dimensions of P and q"
        
        n = max(x.getRows().getCount(), x.getColumns().getCount())
        tmpx = min(x.getRows().getCount(), x.getColumns().getCount())
        if n != P.size[0] or tmpx != 1:
            return "incompatible dimensions of P and x"

        try:
            G, h, dims, A, b, IG, IA = parse_conic_constraints(C)
        except Exception, arg: 
            return "error in constraints: "+str(arg)

        if (G.size[1] != n): 
            return "incompatible dimensions of G and x"
       
        nc = max(z.getRows().getCount(), z.getColumns().getCount())
        if nc != len(C):
            return "incompatible dimensions of dual variables and G"

        try: sol = solvers.coneqp(P, q[:], G, h, dims, A, b) 
        except Exception, arg: return str(arg)

        if sol['status'] == 'optimal':
            
            try: vector_to_CellRange(sol['x'], x)
            except Exception, arg: return "error in x: "+str(arg)

            try: vector_to_CellRange(sol['z'], z, IG)
            except Exception, arg: return "error in z: "+str(arg)
                
            try: vector_to_CellRange(sol['y'], z, IA)
            except Exception, arg: return "error in y: "+str(arg)

            return (0.5*sol['x'][:].T*P*sol['x'][:] + q[:].T*sol['x'][:])[0]

        else:
            for w in [x,z]: clearCellRange(w)		
            return sol['status']

    def gp(self, obj, x, F, z):
        
        err = check_cvxopt_inst()
        if err: return err
        
        try:
            Fo, go = parse_gp_obj(obj)
        except Exception, arg: 
            return "error in objective: "+str(arg)
        
        try:
            K, F, g, IF, A, b, IA = parse_gp_constraints(F)
        except Exception, arg: 
            return "error in constraints: "+str(arg)

        n = max(x.getRows().getCount(), x.getColumns().getCount())
        tmpx = min(x.getRows().getCount(), x.getColumns().getCount())
        if n != F.size[1] or tmpx != 1:
            return "incompatible dimensions of F and x"

        nc = max(z.getRows().getCount(), z.getColumns().getCount())
        if nc != F.size[0] + A.size[0]:
            return "incompatible dimensions of dual variables" 

        K, F, g = [Fo.size[0]] + K, matrix([Fo, F]), matrix([go, g])
                   
        sol = solvers.gp(K, F, g, A=A, b=b) 
        if sol['status'] == 'optimal':

            clearCellRange(z)

            try: vector_to_CellRange(exp(sol['x']), x)
            except Exception, arg: return "error in x: "+str(arg)
            
            try: vector_to_CellRange(sol['znl'], z, IF)
            except Exception, arg: return "error in znl: "+str(arg)  
              
            try: vector_to_CellRange(sol['y'], z, IA)
            except Exception, arg: return "error in y: "+str(arg)
            
            return sum(exp((F*sol['x']+g)[:K[0]]))
        else:
            for w in [x,z]: clearCellRange(w)		
            return sol['status']

    # XAddIn method implementations
    def getProgrammaticFuntionName(self, aDisplayName):
        # Attention: The method name contains a spelling error. 
        # Due to compatibility reasons the name cannot be changed.
        return aDisplayName
	
    def getDisplayFunctionName(self, aProgrammaticName):
        return aProgrammaticName
		
    def getFunctionDescription(self, aProgrammaticName):
        if aProgrammaticName == 'clp':
            return "Linear cone programming solver."
        if aProgrammaticName == 'cqp':
            return "Quadratic cone programming solver."
        if aProgrammaticName == 'gp':
            return "Geomtric programming solver."
        else: return ""
		
    def getDisplayArgumentName(self, aProgrammaticFunctionName, nArg):
        if aProgrammaticFunctionName == 'clp':
            return ['c','x','constraints','dual variables'][nArg]
        elif aProgrammaticFunctionName == 'cqp':
            return ['P','q','x','constraints','dual variables'][nArg]
        elif aProgrammaticFunctionName == 'gp':
            return ['obj','x','constraints','dual variables'][nArg]
        else: return ""
	
    def getArgumentDescription(self, aProgrammaticFunctionName, nArg):
        if aProgrammaticFunctionName == 'clp':
            descr = [
                "objective",
                "primal solution",
                "constraints",
                "dual variables"]
            return descr[nArg]
        elif aProgrammaticFunctionName == 'cqp':
            descr = [
                "matrix with weights for objective",
                "vector with weights for objective",
                "primal solution",
                "linear constraints",
                "dual variables"]
            return descr[nArg]
        elif aProgrammaticFunctionName == 'gp':
            descr = [
                "objective"
                "primal solution",
                "constraints",                
                "dual variables"]
            return descr[nArg]
        else: return ""
	
    def getProgrammaticCategoryName(self, aProgrammaticFunctionName):
        return "Add-in"
	
    def getDisplayCategoryName(self, aProgrammaticFunctionName):
        return "Add-in"
		
    # XLocalizable method implementations
    def setLocale(self, eLocale):
        # the locale is stored and used for getLocale, but otherwise
        # ignored at the moment
        self.Locale = eLocale

    def getLocale(self):
        return self.Locale

	
g_ImplementationHelper.addImplementation( 
    cvxopt, 
    "org.openoffice.sheet.addin.cvxopt", 
    ("org.openoffice.sheet.addin.cvxopt", "com.sun.star.sheet.AddIn"),)

#
# Utility functions for converting to/from CVXOPT matrices
#
def tuples_to_matrix(obj):
    nrows, ncols = len(obj), len(obj[0])
    A = matrix(0.0, (nrows, ncols))
    for i in xrange(nrows):
        for j in xrange(ncols):
            A[i,j] = obj[i][j]
			
    return A

def matrix_to_CellRange(A, cellrng, ox = 0, oy = 0):
    for i in xrange(A.size[0]):
        for j in xrange(A.size[1]):
            try:
                cell = cellrng.getCellByPosition(j+oy,i+ox)
            except:
                raise IndexError, "index (%i,%i) out of range" %(i+ox+1,j+oy+1)
            cell.setValue(A[i,j])

def vector_to_CellRange(x, cellrng, I = None):

    nrows = cellrng.getRows().getCount()
    ncols = cellrng.getColumns().getCount()

    if I is None: I = xrange(len(x))

    for k in xrange(len(x)):
        try:
            if nrows >= ncols:
                cell = cellrng.getCellByPosition(0,I[k])
            else:
                cell = cellrng.getCellByPosition(I[k],0)
        except:
            raise IndexError, "index %i out of range" %(I[k]+1)
        cell.setValue(x[k])

def clearCellRange(cellrng):

    for i in xrange(cellrng.getRows().getCount()):
        for j in xrange(cellrng.getColumns().getCount()):
            cell = cellrng.getCellByPosition(j,i)
            cell.setFormula("")

def parse_gp_obj(C):

    n, K = len(C[0])-1, len(C)
    F, g = matrix(0.0, (K, n)), matrix(0.0, (K,1))
    
    k = 0
    for ci in C:
        F[k,:], g[k] = ci[1:n+1], log(ci[0])
        k += 1

    return F, g
        
def parse_gp_constraints(C):
   
    n, K, neq = len(C[0])-3, [], 0

    parsing_ineq, dim, i = False, 1, 0

    for ci in C:
        if ci[n+1] == '' and ci[-1] == '': 
            if not parsing_ineq:
                raise TypeError, "invalid constraint in row %i" %(i+1)          
            dim += 1
        elif ci[n+1] in ['<','<=']:
            if parsing_ineq: K.append(dim)
            parsing_ineq = True
            dim = 1
            if type(ci[-1]) != float or ci[-1] < 0:
                raise TypeError, "invalid RHS in constraint in row %i" %(i+1)   
        elif ci[n+1] in ['=','==']:
            if parsing_ineq: K.append(dim)
            neq += 1
            parsing_ineq = False
            if type(ci[-1]) != float or ci[-1] < 0:
                raise TypeError, "invalid RHS in constraint in row %i" %(i+1)
        else: raise TypeError, \
                "invalid constraint specifier '%s' in row %i" %(ci[n+1],i+1)
        i+=1

    if parsing_ineq: K.append(dim)

    F, g = matrix(0.0, (sum(K), n)), matrix(0.0, (sum(K),1))
    IF = matrix(0, (len(K),1)) 

    A, b = matrix(0.0, (neq, n)), matrix(0.0, (neq,1))
    IA = matrix(0, (A.size[0],1))

    nineq, neq, knl, i = 0, 0, 0, 0

    for ci in C:
        if ci[n+1] == '': 
            F[nineq,:], g[nineq] = ci[1:n+1], log(ci[0]/scale)
            nineq += 1
        elif ci[n+1] in ['<', '<=']:
            parsing_ineq = True
            scale = ci[-1]
            F[nineq,:], g[nineq], IF[knl] = ci[1:n+1], log(ci[0]/scale), i
            knl += 1
            nineq += 1
        elif ci[n+1] in ['=', '==']:
            parsing_ineq = False
            A[neq,:], b[neq], IA[neq] = ci[1:n+1], log(ci[-1]/ci[0]), i
            neq += 1

        i+=1

    return K, F, g, IF, A, b, IA

def parse_conic_constraints(C):

    n, p, ml, mq, ms = len(C[0])-2, 0, 0, list(), list()
    k, kq, ks = 0, 0, 0

    cType = None
    
    for ci in C:

        if ci[n] != '' and cType == '<q':
            mq.append(kq)
            kq = 0
            cType = None
        elif ci[n] != '' and cType == '<s':
            nk = int(sqrt(ks))
            if abs(nk**2 - ks) > 1e-12:
                raise TypeError, "invalid number of rows in LMI in line %i" %k
            
            ms.append(int(nk))
            ks = 0
            cType = None
        
        if ci[n] in ['>=', '>'] or ci[n] in ['<=', '<']: 
            ml += 1
        elif ci[n] in ['==','=']: 
            p += 1
        elif ci[n] == '' and (cType == '<q'):
            kq += 1
        elif ci[n] == '' and (cType == '<s'):
            ks += 1
        elif ci[n] in ['<q', '<=q']:
            kq = 1
            cType = '<q'
        elif ci[n] in ['<s', '<=s']:
            ks = 1
            cType = '<s'
        else: raise TypeError, \
                "invalid constraint specifier '%s' in row %i" %(str(ci[n]),k)
        k += 1
    
    if cType in ['<q', '<=q']:
        mq.append(kq)
    elif cType in ['<s', '<=s']:
        nk = int(sqrt(ks))
        if abs(nk**2 - ks) > 1e-12:
            raise TypeError, "invalid number of rows in LMI in line %i" %k
            
        ms.append(int(nk))
        
    cType = None

    dims = {'l':ml, 'q':mq, 's':ms}
    mss = [t**2 for t in ms]

    G = matrix(0.0, (ml+sum(mq)+sum(mss),n))
    h = matrix(0.0, (G.size[0],1))
    A, b = matrix(0.0, (p,n)), matrix(0.0, (p,1))    
    IG, IA = matrix(0, G.size), matrix(0, b.size)
    
    k, kineq, keq, kq, cq, ks, cs = 0, 0, 0, 0, 0, 0, 0
    for ci in C:
        if ci[n] in ['<=','<']:
            G[kineq,:], h[kineq] = ci[:n], ci[n+1]
            IG[kineq] = k
            kineq += 1
            cType = None
        elif ci[n] in ['>=', '>']:
            G[kineq,:], h[kineq] = -matrix(ci[:n]).T, -ci[n+1]
            IG[kineq] = k
            kineq += 1
            cType = None
        elif ci[n] in ['==', '=']:
            A[keq,:], b[keq] = ci[:n], ci[n+1]
            IA[keq] = k
            keq += 1        
            cType = None
        elif ci[n] in ['<q', '<=q']:
            cType = '<q'
            cq += 1
            G[ml+sum(mq[:cq-1]),:] = ci[:n]
            h[ml+sum(mq[:cq-1])] = ci[n+1]
            IG[ml+sum(mq[:cq-1])] = k
            kq = 1
        elif ci[n] == '' and cType == '<q':            
            G[ml+sum(mq[:cq-1]) + kq,:] = ci[:n]
            h[ml+sum(mq[:cq-1]) + kq] = ci[n+1]
            IG[ml+sum(mq[:cq-1]) + kq] = k
            kq += 1
        elif ci[n] in ['<s', '<=s']:
            cType = '<s'
            cs += 1
            G[ml+sum(mq)+sum(mss[:cs-1]),:] = ci[:n]
            h[ml+sum(mq)+sum(mss[:cs-1])] = ci[n+1]
            IG[ml+sum(mq)+sum(mss[:cs-1])] = k
            ks = 1
        elif ci[n] == '' and cType == '<s':            
            G[ml+sum(mq)+sum(mss[:cs-1]) + ks,:] = ci[:n]
            h[ml+sum(mq)+sum(mss[:cs-1]) + ks] = ci[n+1]
            IG[ml+sum(mq)+sum(mss[:cs-1]) + ks] = k
            ks += 1

        k += 1
    
    return G, h, dims, A, b, IG, IA
    
# end module
